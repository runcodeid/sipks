module BEightsHelper
end
